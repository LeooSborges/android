package com.example.diego.crudcontatomvc.Persistencia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.diego.crudcontatomvc.Modelo.Contato;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Diego on 11/05/2018.
 */

public class ContatoBD extends SQLiteOpenHelper {
    private static final String NOME_BD = "contatosMVC.sqlite";
    private static final int VERSAO = 10;
    private static ContatoBD contatoBD= null; //Singleton

    //Construtor
    public ContatoBD(Context context) {
        // context, nome do banco, factory, versão
        super(context, NOME_BD, null, VERSAO);
    }

    // utilizado para instanciar a classe, note o IF
    public static ContatoBD getInstance(Context context){
        if(contatoBD == null){
            contatoBD = new ContatoBD(context);
            return contatoBD;
        }else{
            return contatoBD;
        }    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "create table if not exists contato" +
                "( _id integer primary key autoincrement, " +
                " nome text, " +
                " email text, " +
                " celular numeric, " +
                " foto text);";
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // aqui drop tables chama Oncreate
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS contato");
        onCreate(sqLiteDatabase); // chama onCreate e recria o banco de dados
    }

    public long save(Contato contato){
        SQLiteDatabase db = getWritableDatabase(); //abre a conexão com o banco
        try{
            //tupla com: chave, valor
            ContentValues values = new ContentValues();
            values.put("nome", contato.getNome());
            values.put("email", contato.getEmail());
            values.put("celular", contato.getCelular());
            values.put("foto", contato.getFoto());

            if(contato.get_id() == null){
                //insere no banco de dados
                return db.insert("contato", null, values);
            }else
            {//altera no banco de dados
                values.put("_id", contato.get_id());
                return db.update("contato", values, "_id=" + contato.get_id(), null);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {db.close(); }//não esquecer de liberar o recurso
        return 0; //caso não realize as operações
    }

    //retorna a lista de contatos
    public List<Contato> getAll(){
        SQLiteDatabase db = getReadableDatabase();
        try {
            //retorna uma List para os registros contidos no banco de dados
            // d.rawQuery retorna um Cursor, então temos que encaminhar para outro método
            // chamado toList que fará o conversão para lista que precisamos.
            // note que podemos criar outros selects e mandar igualmente para o toList
            return toList(db.rawQuery("SELECT  * FROM contato", null));
        } finally {
            db.close();
        }
    }

 public List<Contato> getByname(String nome){
        SQLiteDatabase db = getReadableDatabase();
        try {
            //retorna uma List para os registros contidos no banco de dados
            // select * from contato where nome LIKE
            return toList(db.rawQuery("SELECT * FROM contato where nome LIKE'" + nome + "%'", null));
        } finally {
            db.close();
        }
    }

    //converte de Cursor para List
    private List<Contato> toList(Cursor c) {
        List<Contato> contatos = new ArrayList<>();
        if (c.moveToFirst()) {
            do {
                Contato contato = new Contato();
                // recupera os atributos do cursor para o conta
                contato.set_id(c.getLong(c.getColumnIndex("_id")));
                contato.setNome(c.getString(c.getColumnIndex("nome")));
                contato.setEmail(c.getString(c.getColumnIndex("email")));
                contato.setCelular(c.getLong(c.getColumnIndex("celular")));
                contato.setFoto(c.getBlob(c.getColumnIndex("foto")));
                //contato.setColorado(Boolean.parseBoolean(String.valueOf(Integer.parseInt("colorado"))));
                contatos.add(contato);
            } while (c.moveToNext());
        }
        return contatos;
    }

    public long delete(Contato contato){
        SQLiteDatabase db = getWritableDatabase(); //abre a conexão com o banco
        try{
            return db.delete("contato", "_id=?", new String[]{String.valueOf(contato.get_id())});
        }
        finally {
            db.close(); //não esquecer de liberar o recurso
        }
    }

}
