package com.example.diego.crudcontatomvc.Controle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.diego.crudcontatomvc.Modelo.Contato;
import com.example.diego.crudcontatomvc.Persistencia.ContatoBD;
import com.example.diego.crudcontatomvc.R;

import java.util.List;

public class Listar extends AppCompatActivity {
    private Contato contato;
    private ContatoBD contatoBD;
    public ListView lista;
    private List<Contato> contatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar);
        lista = (ListView)findViewById(R.id.listviewlistar);

        contato=new Contato();
        contatoBD = ContatoBD.getInstance(this);

        contatos=contatoBD.getAll();

        ArrayAdapter<Contato> adapter=new ArrayAdapter<Contato>
                (this,android.R.layout.simple_list_item_1,contatos);
        lista.setAdapter(adapter);
    }
}
