package com.example.diego.crudcontatomvc.Modelo;

import android.speech.tts.TextToSpeech;

import java.io.Serializable;
import java.util.Arrays;

/**
 * Created by Diego on 11/05/2018.
 */

public class Contato implements Serializable {
    private static final long serialVersionUID=1L;

    private Long _id;
    private String nome;
    private String email;
    private Long celular;
    private byte [] foto;

    @Override
    public String toString() {
        return "Contato{" +
                "_id=" + _id +
                ", nome='" + nome + '\'' +
                ", email='" + email + '\'' +
                ", celular=" + celular +
                ", foto=" +foto +
                '}';
    }

    public Long get_id() {
        return _id;
    }

    public void set_id(Long _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getCelular() {
        return celular;
    }

    public void setCelular(Long celular) {
        this.celular = celular;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }
}
