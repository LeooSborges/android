package com.example.diego.crudcontatomvc.Controle;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.diego.crudcontatomvc.Modelo.Contato;
import com.example.diego.crudcontatomvc.Persistencia.ContatoBD;
import com.example.diego.crudcontatomvc.R;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Locale;

public class ManterContato extends AppCompatActivity implements View.OnClickListener {
    public List<Contato> contatos;
    EditText aliasnome, aliasemail, aliascelular;
    TextView aliascodigo;
    ListView aliaslistviewadicionar;
    private ContatoBD contatoBD;
    private Contato contato;
    private ImageView imvFoto;
    private byte[] imagem = null; //imagem do Contato

    public static byte[] getBitmapAsByteArray(Bitmap bitmap) {
        //criam um stream para ByteArray
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, outputStream); //comprime a imagem
        return outputStream.toByteArray(); //retorna a imagem como um Array de Bytes (byte[])
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar);
        aliasnome=(EditText)findViewById(R.id.editNome);
        aliasemail=(EditText)findViewById(R.id.editEmail);
        aliascelular=(EditText)findViewById(R.id.editCelular);
        aliascodigo=(TextView)findViewById(R.id.text_id);
        imvFoto = (ImageView) findViewById(R.id.imageView);
        imvFoto.setOnClickListener(this);

        //cria novo objeto vazio na memoria
        contato = new Contato();
        // pega uma instancia do banco
        contatoBD = ContatoBD.getInstance(this);

        verificaparametro();
    }

    private void verificaparametro() {
        Intent intent = getIntent();
        if (intent.getSerializableExtra("Objeto")==null){
            // Toast.makeText(this, "Vazio", Toast.LENGTH_SHORT).show();/
            // como o metodo verificarparametro está sendo chamado no oncreate ou no onstart,
            // é necessário verificar com o if acima se o objeto está vazio (novo) ou se o objeto vem de um clique
            // em uma lista.
            contato=new Contato();
        }
        else {
            //  Toast.makeText(this, "Cheio", Toast.LENGTH_SHORT).show();
            contato = (Contato) intent.getSerializableExtra("Objeto"); // nome do parametro recebido é Objeto...
            aliascodigo.setText(contato.get_id().toString());
            aliasnome.setText(contato.getNome());
            aliasemail.setText(contato.getEmail());
            aliascelular.setText(contato.getCelular().toString());
            if (contato.getFoto() != null) {
                //converte byte[] para Bitmap
                Bitmap bitmap = BitmapFactory.decodeByteArray(contato.getFoto(), 0, contato.getFoto().length);
                //carrega a imagem na ImageView do item da ListView
                imvFoto.setImageBitmap(bitmap);
                // para não salvar sem imagem caso o usuário não clique em alterar a imagem (BUG Lógico)
                byte[] img = getBitmapAsByteArray(bitmap); //converte para um fluxo de bytes
                imagem = img; //coloca a imagem no objeto imagem (um array de bytes (byte[]))
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menuitens_manter, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        int id= item.getItemId();
        if(id==R.id.itemsalvar){
            if (contato.get_id() == null) { //se é uma inclusão
                contato = new Contato(); //apaga dados antigos
            }
            contato.setNome(aliasnome.getText().toString());
            contato.setEmail(aliasemail.getText().toString());
            contato.setCelular(Long.valueOf(aliascelular.getText().toString()));
            contato.setFoto(imagem);
            contatoBD.save(contato);
            Toast.makeText(ManterContato.this, "Salvo: " + contato.toString(), Toast.LENGTH_SHORT).show();
        }
        if (id==R.id.itemLocalizar){
            // pega lista de contatos filtrados pelo nome
            contatos=contatoBD.getByname(aliasnome.getText().toString()); //chama o getByName passando nome
            contato = new Contato(); // instancia novo objeto para receber o contato selecionado

            contato.set_id(contatos.get(0).get_id());// seta o Id do contato instanciado
            contato.setNome(contatos.get(0).getNome());
            contato.setEmail(contatos.get(0).getEmail());
            contato.setCelular(contatos.get(0).getCelular());
            contato.setFoto(contatos.get(0).getFoto());

            if (contato.getFoto() != null) {
                //converte byte[] para Bitmap
                Bitmap bitmap = BitmapFactory.decodeByteArray(contato.getFoto(), 0, contato.getFoto().length);
                //carrega a imagem na ImageView do item da ListView
                imvFoto.setImageBitmap(bitmap);
                // para não salvar sem imagem caso o usuário não clique em alterar a imagem (BUG Lógico)
                byte[] img = getBitmapAsByteArray(bitmap); //converte para um fluxo de bytes
                imagem = img; //coloca a imagem no objeto imagem (um array de bytes (byte[]))
            }


            aliasnome.setText(contato.getNome().toString());
            aliasemail.setText(contato.getEmail().toString());
            aliascelular.setText(contato.getCelular().toString());
            aliascodigo.setText(contato.get_id().toString());

            // funciona também

            //  contatos.equals(contato.getNome());
            //contatos.get(0).getNome();
            Toast.makeText(this, "Lista" +contatos.get(0).getNome().toString(), Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.itemexcluir){
            Contato contatoexcluir = new Contato();
            contatoexcluir.set_id(Long.valueOf(aliascodigo.getText().toString()));
            // new Task().execute(SAVE);
            contatoBD.delete(contatoexcluir);
            Toast.makeText(this, "Contato Excluido", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

   @Override
    public void onClick(View v) {
        Intent intent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(Intent.createChooser(intent, "Selecione uma imagem"), 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            Uri arquivoUri = data.getData(); //obtém o URI da imagem
            Bitmap bitmap = null; //mapeia a imagem para um objeto bitmap
            try {
                bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(arquivoUri));
                imvFoto.setImageURI(arquivoUri); //coloca a imagem no ImageView
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            byte[] img = getBitmapAsByteArray(bitmap); //converte para um fluxo de bytes
            imagem = img; //coloca a imagem no objeto imagem (um array de bytes (byte[]))
        }

    }

}
