package com.example.diego.crudcontatomvc.Controle;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.diego.crudcontatomvc.Adaptadores.ContatoAdapter;
import com.example.diego.crudcontatomvc.Modelo.Contato;
import com.example.diego.crudcontatomvc.Persistencia.ContatoBD;
import com.example.diego.crudcontatomvc.R;

import java.util.List;

public class ActivityRecyclerView extends AppCompatActivity {
    protected RecyclerView recyclerView;
    protected List<Contato> contatos;
    protected ContatoAdapter adapter;
    ContatoBD contatoBD;
    Contato contato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        contato = new Contato();
        contatoBD = ContatoBD.getInstance(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
       // recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,true));
       // recyclerView.setLayoutManager(new GridLayoutManager(this,2));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        contatos = contatoBD.getAll();
        recyclerView.setAdapter(adapter = new ContatoAdapter(this, contatos, onClickContato()));
    }

    protected ContatoAdapter.ContatoOnClickListener onClickContato() {
        final Intent intent = new Intent(getBaseContext(), ManterContato.class);
        return new ContatoAdapter.ContatoOnClickListener() {
            @Override
            public void onClickContato(ContatoAdapter.ContatosViewHolder holder, int idx) {
                Contato p = contatos.get(idx);
                // Intent nova= new Intent(this, Editar_Excluir.class);
                intent.putExtra("Objeto", p); //putextraserializable
                startActivity(intent);
            }
        };
    }

    private Activity getActivity() {
        return this;
    }

    public void carregarRecyclerView(List<Contato> contatos) {
        //cria um objeto da classe ListAdapter, um adaptador List -> ListView
        contatos = contatoBD.getAll();
        //associa o adaptador a ListView
        recyclerView.setAdapter(adapter = new ContatoAdapter(this, contatos, onClickContato()));
    }

    @Override
    protected void onStart() {
        super.onStart();
        carregarRecyclerView(contatoBD.getAll());
    }
}