package com.example.diego.crudcontatomvc.Adaptadores;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.diego.crudcontatomvc.Modelo.Contato;
import com.example.diego.crudcontatomvc.R;

import java.util.List;

public class ContatoAdapter extends RecyclerView.Adapter<ContatoAdapter.ContatosViewHolder> {
    private final List<Contato> contatos;
    private final Context context;
    private final ContatoOnClickListener onClickListener;

    public interface ContatoOnClickListener {
         void onClickContato(ContatosViewHolder holder, int idx);
    }

    public ContatoAdapter(Context context, List<Contato> contatos, ContatoOnClickListener onClickListener) {
        this.context = context;
        this.contatos = contatos;
        this.onClickListener = onClickListener;
    }

    @Override
    public ContatosViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Este método cria uma subclasse de RecyclerView.ViewHolder
        // Infla a view do layout
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_do_recycler_contato, viewGroup, false);
        // Cria a classe do ViewHolder
        ContatosViewHolder holder = new ContatosViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final ContatosViewHolder holder, final int position) {
        // Este método recebe o índice do elemento, e atualiza as views que estão dentro do ViewHolder
        Contato c = contatos.get(position);
        // Atualizada os valores nas views
        holder.tNome.setText(c.getNome());
        holder.tEmail.setText(c.getEmail());
        holder.tCelular.setText(c.getCelular().toString());
        if (c.getFoto()!= null) {
            //converte byte[] para Bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(c.getFoto(), 0, c.getFoto().length);
            //carrega a imagem na ImageView do item da ListView
            holder.img.setImageBitmap(bitmap);
        } else {
            //carrega a imagem padrão (se não houver imagem no Cursor)
            holder.img.setImageResource(R.mipmap.ic_launcher);
        }
        // holder.img.setImageResource(c.foto);       // Click
        if (onClickListener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Chama o listener para informar que clicou no Cachorro
                    onClickListener.onClickContato(holder, position);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return this.contatos != null ? this.contatos.size() : 0;
    }

    // Subclasse de RecyclerView.ViewHolder. Contém todas as views.
    public static class ContatosViewHolder extends RecyclerView.ViewHolder {
        public TextView tNome;
        public TextView tEmail;
        public TextView tCelular;
        ImageView img;
        ProgressBar progress;
        private View view;

        public ContatosViewHolder(View view) {
            super(view);
            this.view = view;
            // Cria as views para salvar no ViewHolder
            tNome = (TextView) view.findViewById(R.id.tNome);
            tEmail = (TextView) view.findViewById(R.id.tEmail);
            tCelular = (TextView) view.findViewById(R.id.tCelular);
            img = (ImageView) view.findViewById(R.id.img);
            progress = (ProgressBar) view.findViewById(R.id.progress);
         }
    }
}