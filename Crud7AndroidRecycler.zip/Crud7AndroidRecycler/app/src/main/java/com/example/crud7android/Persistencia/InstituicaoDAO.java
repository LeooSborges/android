package com.example.crud7android.Persistencia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;

import com.example.crud7android.Modelo.Instituicao;

import java.util.ArrayList;
import java.util.List;

public class InstituicaoDAO {
    private DbGateway gw;

    public InstituicaoDAO(Context ctx){
        gw = DbGateway.getInstance(ctx);
    }

    public long save(Instituicao instituicao){
        // SQLiteDatabase db = getWritableDatabase(); //abre a conexão com o banco não precisa mais
        try{
            //tupla com: chave, valor
            ContentValues values = new ContentValues();
            values.put("instituicao", instituicao.getInstituicao());
            if(instituicao.get_id() == null){
                //insere no banco de dados
                return gw.getDatabase().insert("instituicao", null, values);
            }else
            {
                //altera no banco de dados
                values.put("_id", instituicao.get_id());
                return gw.getDatabase().update("instituicao", values,"_id=" + instituicao.get_id(), null);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    //retorna a lista de contatos
    public List <Instituicao> getAll(){
        try {
            return toList(gw.getDatabase().rawQuery("SELECT * FROM instituicao", null));
        } finally {

        }
    }
    //converte de Cursor para List
    private List<Instituicao> toList(Cursor c) {
        List<Instituicao> instituicoes = new ArrayList <>();
        if (c.moveToFirst()) {
            do {
                Instituicao instituicao = new Instituicao();

                instituicao.set_id(c.getInt(c.getColumnIndex("_id")));
                instituicao.setInstituicao(c.getString(c.getColumnIndex("instituicao")));

                instituicoes.add(instituicao);
            } while (c.moveToNext());
        }
        return instituicoes;
    }


    //retorna a lista de profissoes // não está sendo utilizado // vide DAO de Contatos
    public Instituicao getUmaInstituicao(Integer id_instituicao){
        try {
            return umaInstituicao(gw.getDatabase().rawQuery("SELECT * FROM instituicao where _id="+id_instituicao, null));

        } finally {

        }
    }

    //converte de Cursor para List // não está sendo utilizada
    private Instituicao umaInstituicao(Cursor c) {
        if (c.moveToFirst()) {
            Instituicao instituicao = new Instituicao();

            instituicao.set_id(c.getInt(c.getColumnIndex("_id")));
            instituicao.setInstituicao(c.getString(c.getColumnIndex("instituicao")));
            return instituicao;
        }
        return null;
    }


    public List<Instituicao> getByInstituicao(String instituicao){
        try {
            //retorna uma List para os registros contidos no banco de dados
            // select * from cachorro
            return toList(gw.getDatabase().rawQuery("SELECT * FROM instituicao where instituicao LIKE'" + instituicao + "%'", null));

        } finally {

        }
    }

    public long delete(Instituicao instituicao){

        try{
            return gw.getDatabase().delete("instituicao", "_id=?", new String[]{String.valueOf(instituicao.get_id())});
        }
        finally {

        }
    }
}