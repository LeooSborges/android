package com.example.crud7android.Modelo;

public class Disciplina {
    Integer _id;
    String disciplina;

    @Override
    public String toString() {
        return " " + disciplina;
    }

    public Integer get_id() {
        return _id;
    }

    public void set_id(Integer _id) {
        this._id = _id;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }
}