package com.example.crud7android.Controle;


import android.content.ContentResolver;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.crud7android.Modelo.Disciplina;
import com.example.crud7android.Modelo.Instituicao;
import com.example.crud7android.Modelo.Professor;
import com.example.crud7android.Persistencia.DbGateway;
import com.example.crud7android.Persistencia.DisciplinaDAO;
import com.example.crud7android.Persistencia.InstituicaoDAO;
import com.example.crud7android.Persistencia.ProfessorDAO;
import com.example.crud7android.R;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.util.List;

import static android.app.Activity.RESULT_OK;


public class manterProfessor extends Fragment implements AdapterView.OnItemSelectedListener, View.OnClickListener {
    EditText aliasnome;
    TextView aliascodigo;
    Spinner aliasdisciplina;
    Spinner aliasinstituicao;
    ListView aliaslistview;
    DisciplinaDAO disciplinaDAO;
    Disciplina disciplina;
    ProfessorDAO professorDAO;
    Professor professor;
    InstituicaoDAO instituicaoDAO;
    Instituicao instituicao;
    Button salvar;
    List <Professor> professores;
    List<Disciplina> disciplinas;
    List<Instituicao> instituicoes;
    private ImageView aliasFotoProf;
    private byte[] foto = null;

    public static byte[] getBitmapAsByteArray(Bitmap bitmap) {
        //criam um stream para ByteArray
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, outputStream); //comprime a imagem
        return outputStream.toByteArray(); //retorna a imagem como um Array de Bytes (byte[])
    }

    public manterProfessor() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_manter_professor, container, false);
        setHasOptionsMenu(true);
        aliascodigo = view.findViewById(R.id.id_professor);
        aliasnome = view.findViewById(R.id.editNome_professor);
        aliasdisciplina = view.findViewById(R.id.spinnerDisciplina);
        aliasinstituicao = view.findViewById(R.id.spinnerInstituicao);
        aliaslistview = view.findViewById(R.id.listaProf);
        aliasFotoProf = view.findViewById(R.id.imageView);
        aliasFotoProf.setOnClickListener(this);



//        professorDAO = DbGateway.getInstance(getContext);


        //inicializa disciplinas, instituicao, professor e suas DAO's
        disciplinaDAO = new DisciplinaDAO(getContext());
        disciplina = new Disciplina();

        instituicaoDAO = new InstituicaoDAO(getContext());
        instituicao = new Instituicao();

        professorDAO = new ProfessorDAO(getContext());
        professor = new Professor();




        carregalistview();
        //lista do spinner de disciplinas, instituicoes
        instituicoes = instituicaoDAO.getAll();
        ArrayAdapter <Instituicao> adaptadorInstituicao =
                new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1,instituicoes);
        aliasinstituicao.setAdapter(adaptadorInstituicao);
        aliasinstituicao.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                instituicao = (Instituicao) parent.getAdapter().getItem(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });




        disciplinas = disciplinaDAO.getAll();
        ArrayAdapter<Disciplina> adaptadorDisciplinas = new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1, disciplinas);
        aliasdisciplina.setAdapter(adaptadorDisciplinas);
        aliasdisciplina.setOnItemSelectedListener(this);


        return view;
    }



    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater){
        inflater.inflate(R.menu.menu_manter,menu);
    }

    private void carregalistview() {
        //lista de professores
        professores = professorDAO.getAll();
        ArrayAdapter<Professor> adaptadorProfessor =
                new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1,professores);
        aliaslistview.setAdapter(adaptadorProfessor);
        adaptadorProfessor.notifyDataSetChanged();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        disciplina = (Disciplina)parent.getAdapter().getItem(position); //obtém a Disciplina Objeto
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();
        if(id==R.id.salvar){
            if (professor.get_id()==null){
                professor=new Professor();
            }
            professor.setNome(aliasnome.getText().toString());
            professor.setDisciplina(disciplina);
            professor.setInstituicao(instituicao);
            professor.setFoto(foto);

            professorDAO.save(professor);
            Toast.makeText(getContext(),
                    "professor Salvo com Sucesso"+ professor.toString(), Toast.LENGTH_LONG).show();
            carregalistview();
            limparCampos();
            return true;

        } else
        if (id==R.id.localizar){
            // pega lista de professores filtrados pelo nome
            professores=professorDAO.getByname(aliasnome.getText().toString()); //chama o getByName passando nome
            professor = new Professor(); // instancia novo objeto para receber o professor selecionado
            professor.set_id(professores.get(0).get_id());// seta o Id do professor instanciado
            professor.setNome(professores.get(0).getNome());
            professor.setDisciplina(professores.get(0).getDisciplina());
            professor.setInstituicao(professores.get(0).getInstituicao());
            professor.setFoto(professores.get(0).getFoto());


            aliascodigo.setText(professor.get_id().toString());
            aliasnome.setText(professor.getNome().toString());
            aliasdisciplina.setSelection(getIndex(aliasdisciplina, professor.getDisciplina().toString()));
            aliasinstituicao.setSelection(getIndex(aliasinstituicao, professor.getInstituicao().toString()));

            if (professor.getFoto() != null) {
                //converte byte[] para Bitmap
                Bitmap bitmap = BitmapFactory.decodeByteArray(professor.getFoto(), 0 , professor.getFoto().length);
                //carrega a imagem na ImageView do item da ListView
                aliasFotoProf.setImageBitmap(bitmap);
                // para não salvar sem imagem caso o usuário não clique em alterar a imagem (BUG Lógico)
                byte[] img = getBitmapAsByteArray(bitmap); //converte para um fluxo de bytes
                foto = img; //coloca a imagem no objeto imagem (um array de bytes (byte[]))
            }


            //aliasdisciplina.setText(professor.getDisciplina().toString());
            Toast.makeText(getContext(), "Lista" +professores.get(0).getNome().toString(), Toast.LENGTH_SHORT).show();
            carregalistview();
            return true;
        }
        else
        if (id==R.id.excluir){
            Professor professorexcluir = new Professor();
            professorexcluir.set_id(Integer.valueOf(aliascodigo.getText().toString()));
            // new Task().execute(SAVE);
            professorDAO.delete(professorexcluir);
            Toast.makeText(getContext(), "Professor Excluido", Toast.LENGTH_SHORT).show();
            limparCampos();
            carregalistview();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void limparCampos() {
        aliascodigo.setText("");
        aliasnome.setText("");
        professor=new Professor();
    }

    //private method busca o index da posição pelo nome da raca
    private int getIndex(Spinner spinner, String myString){
        for (int i=0;i<spinner.getCount();i++){
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(myString)){
                return i;
            }
        }
        return 0;
    }


    @Override
    public void onClick(View v) {
        Intent intent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(Intent.createChooser(intent, "Selecione uma imagem"), 0);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            Uri arquivoUri = data.getData(); //obtém o URI da imagem
            Bitmap bitmap = null; //mapeia a imagem para um objeto bitmap
            try {

                bitmap = BitmapFactory.decodeStream(getActivity().getContentResolver().openInputStream(arquivoUri));
                aliasFotoProf.setImageURI(arquivoUri); //coloca a imagem no ImageView
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            byte[] img = getBitmapAsByteArray(bitmap); //converte para um fluxo de bytes
            foto = img; //coloca a imagem no objeto imagem (um array de bytes (byte[]))
        }

    }


}
