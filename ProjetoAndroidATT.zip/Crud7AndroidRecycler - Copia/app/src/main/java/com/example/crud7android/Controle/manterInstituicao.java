package com.example.crud7android.Controle;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.crud7android.Modelo.Instituicao;
import com.example.crud7android.Persistencia.InstituicaoDAO;
import com.example.crud7android.R;

import java.util.List;

public class manterInstituicao extends Fragment {
    EditText aliasinstituicao;
    TextView aliascodigo;
    Instituicao instituicao;
    ListView listView;
    InstituicaoDAO instituicaoDAO;
    List <Instituicao> instituicoes;

    public manterInstituicao() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_manter_instituicao, container, false);
        setHasOptionsMenu(true);
        aliascodigo=view.findViewById(R.id.id_instituicao);
        aliasinstituicao = view.findViewById(R.id.editInstituicao);
        listView = view.findViewById(R.id.listView_instituicao);

        instituicaoDAO = new InstituicaoDAO(getContext());
        instituicao = new Instituicao();
        carregalistview();

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater){
        inflater.inflate(R.menu.menu_manter,menu);
    }

    private void carregalistview() {
        instituicoes = instituicaoDAO.getAll();
        ArrayAdapter <Instituicao> adaptador = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, instituicoes);
        listView.setAdapter(adaptador);
        adaptador.notifyDataSetChanged();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();
        if(id==R.id.salvar){
            if (instituicao.get_id()==null){
                instituicao=new Instituicao();
            }
            instituicao.setInstituicao(aliasinstituicao.getText().toString());
            instituicaoDAO.save(instituicao);
            Toast.makeText(getContext(), "Instituicao Salva: " + instituicao.getInstituicao().toString(), Toast.LENGTH_SHORT).show();
            carregalistview();// para atualizar
            return true;
        } else
        if (id==R.id.localizar){
            // pega lista de contatos filtrados pelo instituicao
            instituicoes=instituicaoDAO.getByInstituicao(aliasinstituicao.getText().toString()); //chama o getByName passando instituicao
            instituicao = new Instituicao(); // instancia novo objeto para receber o profissao selecionada
            instituicao.set_id(instituicoes.get(0).get_id());// seta o Id do contato instanciado
            instituicao.setInstituicao(instituicoes.get(0).getInstituicao());
            aliasinstituicao.setText(instituicao.getInstituicao().toString());
            aliascodigo.setText(instituicao.get_id().toString());
            Toast.makeText(getContext(), "Lista" +instituicoes.get(0).getInstituicao().toString(), Toast.LENGTH_SHORT).show();
            carregalistview();// para atualizar
            return true;
        }
        else
        if (id==R.id.excluir){
            instituicao.set_id(Integer.parseInt(aliascodigo.getText().toString()));
            // new Task().execute(SAVE);
            instituicaoDAO.delete(instituicao);
            Toast.makeText(getContext(), "Instituicao Excluida com Sucesso", Toast.LENGTH_SHORT).show();
            limparCampos();
            carregalistview();// para atulaizar
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void limparCampos() {
        aliascodigo.setText("");
        aliasinstituicao.setText("");
        instituicao=new Instituicao();

    }

}
