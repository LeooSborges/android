package com.example.crud7android.Persistencia;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class BancoLocal extends SQLiteOpenHelper {

    private static final String NOME_BD = "bancolocalProfessores.sqlite";
    private static final int VERSAO = 21;
    private static BancoLocal bancoLocal = null; //Singleton

    public BancoLocal(Context context) {
        super(context, NOME_BD, null, VERSAO);
    }

    public static BancoLocal getInstance(Context context){
        if(bancoLocal == null){
            bancoLocal = new BancoLocal(context);
            return bancoLocal;
        }else{
            return bancoLocal;
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table if not exists professor" +
                "( _id integer primary key autoincrement, " +
                " nome text, " +
                " id_disciplina numeric, " +
                " id_instituicao numeric, " +
                " imagem blob);";
        db.execSQL(sql);

        String sql2 = "create table if not exists disciplina" +
                "( _id integer primary key autoincrement, " +
                " disciplina text);";
        db.execSQL(sql2);


        String sql3 = "create table if not exists instituicao" +
                "( _id integer primary key autoincrement, " +
                " instituicao text);";
        db.execSQL(sql3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
// Caso mude a versão do banco de dados, podemos executar um SQL aqui
        // exemplo:
        Log.d("teste", "Upgrade da versão " + oldVersion + " para "
                + newVersion + ", destruindo tudo.");
        db.execSQL("DROP TABLE IF EXISTS professor");
        db.execSQL("DROP TABLE IF EXISTS disciplina");
        db.execSQL("DROP TABLE IF EXISTS instituicao");
        onCreate(db); // chama onCreate e recria o banco de dados
        Log.i("teste", "Executou o script de upgrade da tabela professores.");
    }
}