package com.example.crud7android.Controle;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.crud7android.Modelo.Disciplina;
import com.example.crud7android.Persistencia.DisciplinaDAO;
import com.example.crud7android.R;

import java.util.List;

public class manterDisciplina extends Fragment {
    EditText aliasdisciplina;
    TextView aliascodigo;
    Disciplina disciplina;
    ListView listView;
    DisciplinaDAO disciplinaDAO;
    List <Disciplina> disciplinas;

    public manterDisciplina() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_manter_disciplina, container, false);
        setHasOptionsMenu(true);
        aliascodigo=view.findViewById(R.id.id_disciplina);
        aliasdisciplina = view.findViewById(R.id.editDisciplina);
        listView = view.findViewById(R.id.listView_disciplina);

        disciplinaDAO = new DisciplinaDAO(getContext());
        disciplina = new Disciplina();
        carregalistview();

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater){
        inflater.inflate(R.menu.menu_manter,menu);
    }

    private void carregalistview() {
        disciplinas = disciplinaDAO.getAll();
        ArrayAdapter <Disciplina> adaptador = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, disciplinas);
        listView.setAdapter(adaptador);
        adaptador.notifyDataSetChanged();
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();
        if(id==R.id.salvar){
            if (disciplina.get_id()==null){
                disciplina=new Disciplina();
            }
            disciplina.setDisciplina(aliasdisciplina.getText().toString());
            disciplinaDAO.save(disciplina);
            Toast.makeText(getContext(), "Disciplina Salva: " + disciplina.getDisciplina().toString(), Toast.LENGTH_SHORT).show();
            carregalistview();// para atualizar
            return true;
        } else
        if (id==R.id.localizar){
            // pega lista de contatos filtrados pelo disciplina
            disciplinas=disciplinaDAO.getByDisciplina(aliasdisciplina.getText().toString()); //chama o getByName passando disciplina
            disciplina = new Disciplina(); // instancia novo objeto para receber o profissao selecionada
            disciplina.set_id(disciplinas.get(0).get_id());// seta o Id do contato instanciado
            disciplina.setDisciplina(disciplinas.get(0).getDisciplina());
            aliasdisciplina.setText(disciplina.getDisciplina().toString());
            aliascodigo.setText(disciplina.get_id().toString());
            Toast.makeText(getContext(), "Lista" +disciplinas.get(0).getDisciplina().toString(), Toast.LENGTH_SHORT).show();
            carregalistview();// para atualizar
            return true;
        }
        else
        if (id==R.id.excluir){
            disciplina.set_id(Integer.parseInt(aliascodigo.getText().toString()));
            // new Task().execute(SAVE);
            disciplinaDAO.delete(disciplina);
            Toast.makeText(getContext(), "Disciplina Excluida com Sucesso", Toast.LENGTH_SHORT).show();
            limparCampos();
            carregalistview();// para atulaizar
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void limparCampos() {
        aliascodigo.setText("");
        aliasdisciplina.setText("");
        disciplina=new Disciplina();

    }

}

