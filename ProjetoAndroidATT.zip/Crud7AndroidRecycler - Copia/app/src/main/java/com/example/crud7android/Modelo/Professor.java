package com.example.crud7android.Modelo;

import java.io.Serializable;

public class Professor implements Serializable {
    private static final long serialVersionUID=1L;

    private Integer _id;
    private String nome;
    private Disciplina disciplina;
    private Instituicao instituicao;



    private byte [] foto;

    @Override
    public String toString() {
        return "Professor: " + nome +
                " - Id: " + _id +
                "\nDisciplina: " + disciplina +
                " - Instituicao: " + instituicao +
                " - Foto: " + foto +
                " ";
    }

    public Integer get_id() {
        return _id;
    }

    public void set_id(Integer _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public Instituicao getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(Instituicao instituicao) {
        this.instituicao = instituicao;
    }

    public byte[] getFoto() {
        return foto;
    }
    public void setFoto(byte[] foto) {
        this.foto = foto;
    }



}