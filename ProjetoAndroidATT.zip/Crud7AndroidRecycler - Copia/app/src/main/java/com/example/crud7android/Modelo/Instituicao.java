package com.example.crud7android.Modelo;

public class Instituicao {
    Integer _id;
    String instituicao;
    //obs: add geolocalização


    @Override
    public String toString() {
        return " " + instituicao;
    }

    public Integer get_id() {
        return _id;
    }

    public void set_id(Integer _id) {
        this._id = _id;
    }

    public String getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }
}