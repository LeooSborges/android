package com.example.crud7android.Persistencia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;

import com.example.crud7android.Modelo.Disciplina;

import java.util.ArrayList;
import java.util.List;

public class DisciplinaDAO {
    private DbGateway gw;

    public DisciplinaDAO(Context ctx){
        gw = DbGateway.getInstance(ctx);
    }

    public long save(Disciplina disciplina){
        // SQLiteDatabase db = getWritableDatabase(); //abre a conexão com o banco não precisa mais
        try{
            //tupla com: chave, valor
            ContentValues values = new ContentValues();
            values.put("disciplina", disciplina.getDisciplina());
            if(disciplina.get_id() == null){
                //insere no banco de dados
                return gw.getDatabase().insert("disciplina", null, values);
            }else
            {
                //altera no banco de dados
                values.put("_id", disciplina.get_id());
                return gw.getDatabase().update("disciplina", values,"_id=" + disciplina.get_id(), null);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    //retorna a lista
    public List <Disciplina> getAll(){
        try {
            return toList(gw.getDatabase().rawQuery("SELECT * FROM disciplina", null));
        } finally {

        }
    }
    //converte de Cursor para List
    private List<Disciplina> toList(Cursor c) {
        List<Disciplina> disciplinas = new ArrayList <>();
        if (c.moveToFirst()) {
            do {
                Disciplina disciplina = new Disciplina();

                disciplina.set_id(c.getInt(c.getColumnIndex("_id")));
                disciplina.setDisciplina(c.getString(c.getColumnIndex("disciplina")));

                disciplinas.add(disciplina);
            } while (c.moveToNext());
        }
        return disciplinas;
    }


    //retorna a lista // não está sendo utilizado // vide DAO
    public Disciplina getUmaDisciplina(Integer id_disciplina){
        try {
            return umaDisciplina(gw.getDatabase().rawQuery("SELECT * FROM disciplina where _id="+id_disciplina, null));

        } finally {

        }
    }

    //converte de Cursor para List // não está sendo utilizada
    private Disciplina umaDisciplina(Cursor c) {
        if (c.moveToFirst()) {
            Disciplina disciplina = new Disciplina();

            disciplina.set_id(c.getInt(c.getColumnIndex("_id")));
            disciplina.setDisciplina(c.getString(c.getColumnIndex("disciplina")));
            return disciplina;
        }
        return null;
    }


    public List<Disciplina> getByDisciplina(String disciplina){
        try {
            //retorna uma List para os registros contidos no banco de dados
            // select * from cachorro
            return toList(gw.getDatabase().rawQuery("SELECT * FROM disciplina where disciplina LIKE'" + disciplina + "%'", null));

        } finally {

        }
    }

    public long delete(Disciplina disciplina){

        try{
            return gw.getDatabase().delete("disciplina", "_id=?", new String[]{String.valueOf(disciplina.get_id())});
        }
        finally {

        }
    }}