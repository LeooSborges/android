package com.example.crud7android.Persistencia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;

import com.example.crud7android.Modelo.Disciplina;
import com.example.crud7android.Modelo.Instituicao;
import com.example.crud7android.Modelo.Professor;

import java.util.ArrayList;
import java.util.List;

public class ProfessorDAO {
    private DbGateway gw;

    public ProfessorDAO(Context ctx){
        gw = DbGateway.getInstance(ctx);
    }

    public long save(Professor professor){
        // SQLiteDatabase db = getWritableDatabase(); //abre a conexão com o banco, não é necessario mais
        try{
            //tupla com: chave, valor
            ContentValues values = new ContentValues();
            values.put("nome", professor.getNome());
            // para profissão recupera o id da disciplina/ instituicao

            values.put("id_disciplina", professor.getDisciplina().get_id());
            values.put("id_instituicao", professor.getInstituicao().get_id());
            values.put("imagem", professor.getFoto());
            if(professor.get_id() == null){
                return gw.getDatabase().insert("professor", null, values);
            }else {
                values.put("_id", professor.get_id());
                return gw.getDatabase().update("professor", values,"_id=" + professor.get_id(), null); }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    //retorna a lista de professores
    public List <Professor> getAll(){
        try {
            return toList(gw.getDatabase().rawQuery("SELECT * FROM professor", null));
        } finally {
        }
    }
    //converte de Cursor para List
    private List<Professor> toList(Cursor c) {
        List<Professor> professores = new ArrayList <>();
        if (c.moveToFirst()) {
            do {
                Professor professor = new Professor();
                professor.set_id(c.getInt(c.getColumnIndex("_id")));
                professor.setNome(c.getString(c.getColumnIndex("nome")));
                // recupera a disciplina/ instituicao, buscando pelo Id que está gravado no banco.
                Integer id_disc=c.getInt(c.getColumnIndex("id_disciplina"));
                professor.setDisciplina(getUmaDisciplina(id_disc)); // busca a disciplina em método local da DAO
                Integer id_inst=c.getInt(c.getColumnIndex("id_instituicao"));
                professor.setInstituicao(getUmaInstituicao(id_inst)); // busca a instituicao em método local da DAO
                professor.setFoto(c.getBlob(c.getColumnIndex("imagem")));
                professores.add(professor);
            } while (c.moveToNext());
        }
        return professores;
    }

    public List<Professor> getByname(String nome){
        try {
            return toList(gw.getDatabase().rawQuery("SELECT * FROM professor where nome LIKE'" + nome + "%'", null));
        } finally {

        }
    }
    //retorna a lista de disciplinas
    public Disciplina getUmaDisciplina(Integer id_disciplina){
        try {
            return umaDisciplina(gw.getDatabase().rawQuery("SELECT * FROM disciplina where _id="+id_disciplina, null));

        } finally {
        }
    }
    //retorna a lista de instituicao
    public Instituicao getUmaInstituicao(Integer id_instituicao){
        try {
            return umaInstituicao(gw.getDatabase().rawQuery("SELECT * FROM instituicao where _id="+id_instituicao, null));

        } finally {
        }
    }
    //converte de Cursor para List
    private Disciplina umaDisciplina(Cursor c) {
        if (c.moveToFirst()) {
            Disciplina disciplina = new Disciplina();
            disciplina.set_id(c.getInt(c.getColumnIndex("_id")));
            disciplina.setDisciplina(c.getString(c.getColumnIndex("disciplina")));
            return disciplina;
        }
        // caso não ache a disciplina retorna nulo
        return null;
    }
    private Instituicao umaInstituicao(Cursor c) {
        if (c.moveToFirst()) {
            Instituicao instituicao = new Instituicao();
            instituicao.set_id(c.getInt(c.getColumnIndex("_id")));
            instituicao.setInstituicao(c.getString(c.getColumnIndex("instituicao")));
            return instituicao;
        }
        // caso não ache a instituicao retorna nulo
        return null;
    }

    public long delete(Professor professor){

        try{
            return gw.getDatabase().delete("professor", "_id=?", new String[]{String.valueOf(professor.get_id())});
        }
        finally {

        }
    }
}
