package com.example.crud7android.Controle;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Adapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.crud7android.Adaptadores.ProfessorAdapter;
import com.example.crud7android.Modelo.Professor;
import com.example.crud7android.Persistencia.ProfessorDAO;
import com.example.crud7android.R;

import java.util.List;

public class recycler extends AppCompatActivity {
    protected RecyclerView recyclerView;
    protected List <Professor> professores;
    protected ProfessorAdapter adapter;
    ProfessorDAO professorDAO;
    Professor professor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_prof);
        professor = new Professor();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,true));
        // recyclerView.setLayoutManager(new GridLayoutManager(this,2));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        professores = professorDAO.getAll();
        recyclerView.setAdapter(adapter = new ProfessorAdapter(this, professores, onClickProfessor()));
    }

    protected ProfessorAdapter.ProfessorOnClickListener onClickProfessor() {
        final Intent intent = new Intent(getBaseContext(), manterProfessor.class);
        return new ProfessorAdapter.ProfessorOnClickListener() {
            @Override
            public void onClickProfessor(ProfessorAdapter.ProfessoresViewHolder holder, int idx) {
                Professor p = professores.get(idx);
                // Intent nova= new Intent(this, Editar_Excluir.class);
                intent.putExtra("Objeto", p.get_id()); //putextraserializable
                startActivity(intent);
            }
        };
    }

    private Activity getActivity() {
        return this;
    }

    public void carregarRecyclerView(List<Professor> professores) {
        //cria um objeto da classe ListAdapter, um adaptador List -> ListView
        professores = professorDAO.getAll();
        //associa o adaptador a ListView
        recyclerView.setAdapter(adapter = new ProfessorAdapter(this, professores, onClickProfessor()));
    }

    @Override
    protected void onStart() {
        super.onStart();
        carregarRecyclerView(professorDAO.getAll());
    }
}