package com.example.crud7android.Adaptadores;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.crud7android.Modelo.Professor;
import com.example.crud7android.R;

import java.util.List;

public class ProfessorAdapter extends RecyclerView.Adapter<ProfessorAdapter.ProfessoresViewHolder> {
    private final List<Professor> professores;
    private final Context context;
    private final ProfessorOnClickListener onClickListener;

    public interface ProfessorOnClickListener {
        void onClickProfessor(ProfessoresViewHolder holder, int idx);
    }

    public ProfessorAdapter(Context context, List<Professor> professores, ProfessorOnClickListener onClickListener) {
        this.context = context;
        this.professores = professores;
        this.onClickListener = onClickListener;
    }



    @Override
    public ProfessoresViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Este método cria uma subclasse de RecyclerView.ViewHolder
        // Infla a view do layout
        View view = LayoutInflater.from(context).inflate(R.layout.activity_recycler, viewGroup, false);
        // Cria a classe do ViewHolder
        ProfessoresViewHolder holder = new ProfessoresViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final ProfessoresViewHolder holder, final int position) {
        // Este método recebe o índice do elemento, e atualiza as views que estão dentro do ViewHolder
        Professor c = professores.get(position);
        // Atualizada os valores nas views
        holder.tNome.setText(c.getNome());
        holder.tDisciplina.setText(c.getDisciplina().toString());
        holder.tInstituicao.setText(c.getInstituicao().toString());
        if (c.getFoto()!= null) {
            //converte byte[] para Bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(c.getFoto(), 0, c.getFoto().length);
            //carrega a imagem na ImageView do item da ListView
            holder.foto.setImageBitmap(bitmap);
        } else {
            //carrega a imagem padrão (se não houver imagem no Cursor)
            holder.foto.setImageResource(R.mipmap.ic_launcher);
        }
        // holder.img.setImageResource(c.foto);       // Click
        if (onClickListener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Chama o listener para informar que clicou no Cachorro
                    onClickListener.onClickProfessor(holder, position);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return this.professores != null ? this.professores.size() : 0;
    }


    public static class ProfessoresViewHolder extends RecyclerView.ViewHolder {
        public TextView tNome;
        public TextView tDisciplina;
        public TextView tInstituicao;
        ImageView foto;
        ProgressBar progress;
        private View view;

        public ProfessoresViewHolder(View view) {
            super(view);
            this.view = view;
            // Cria as views para salvar no ViewHolder
            tNome = (TextView) view.findViewById(R.id.editNome_professor);
            tDisciplina = (TextView) view.findViewById(R.id.editDisciplina);
            tInstituicao = (TextView) view.findViewById(R.id.editInstituicao);
            foto = (ImageView) view.findViewById(R.id.imageView);
        }
    }

    // Subclasse de RecyclerView.ViewHolder. Contém todas as views.

}